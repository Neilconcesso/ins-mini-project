from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import hashes, serialization

def sign_message(message: bytes):
    with open("dsa_private_key.pem", "rb") as key_file:
        private_key = serialization.load_pem_private_key(key_file.read(), password=None)

    signature = private_key.sign(message, hashes.SHA256())
    with open("signature.sig", "wb") as f:
        f.write(signature)

    print("Message signed successfully.")
    return signature

if __name__ == "__main__":
    msg = input("Enter message to sign: ").encode()
    sign_message(msg)
