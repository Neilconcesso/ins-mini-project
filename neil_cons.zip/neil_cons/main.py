import keygen
import sign
import verify

def main():
    while True:
        print("\nDSS Authentication System")
        print("1. Generate DSA Keys")
        print("2. Sign a Message")
        print("3. Verify a Signature")
        print("4. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            keygen.generate_dsa_keys()
        elif choice == "2":
            msg = input("Enter message to sign: ").encode()
            sign.sign_message(msg)
        elif choice == "3":
            msg = input("Enter original message: ").encode()
            with open("signature.sig", "rb") as f:
                sig = f.read()
            verify.verify_signature(msg, sig)
        elif choice == "4":
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()

