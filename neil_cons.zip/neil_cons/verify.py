from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import hashes, serialization

def verify_signature(message: bytes, signature: bytes):
    with open("dsa_public_key.pem", "rb") as key_file:
        public_key = serialization.load_pem_public_key(key_file.read())

    try:
        public_key.verify(signature, message, hashes.SHA256())
        print("Signature is valid.")
    except Exception as e:
        print("Signature verification failed.")

if __name__ == "__main__":
    message = input("Enter original message: ").encode()
    with open("signature.sig", "rb") as f:
        signature = f.read()
    verify_signature(message, signature)
